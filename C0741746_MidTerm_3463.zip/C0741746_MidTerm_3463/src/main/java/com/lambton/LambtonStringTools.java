package com.lambton;

public class LambtonStringTools {


    public void reverse() {
        String s = "lambton";
        int totalchar;

        for (int i = s.length() - 1; i > 0; i--) {

            System.out.print(s.charAt(i));

        }}
//-----------------------------------------
       /* public void binaryToDecimal() {

            String s2 = null;
            int n=s2.nextInt();

                    int decimal=0,p=0;

                    while(n!=0)
                    {
                        decimal+=((n%10)*Math.pow(2,p));
                        n=n/10;
                        p++;
                    }

                    System.out.println(decimal);*/

   //-----------------------------------------

      public void initials(String name){

        if (name.length() == 0) {
            return;
        }


        System.out.print(Character.toUpperCase(
            name.charAt(0)));
        for (int i = 1; i < name.length() - 1; i++)
            if (name.charAt(i) == ' ')
                System.out.print(" " + Character.toUpperCase(
                                        name.charAt(i + 1)));
    }


//-----------------------------------------------------
        public char[] mostFrequent (String str)
        {
            int temp = 0;
            int counter = 0;
            int currentvalue = 0;

            char[] maxchar = new char[str.length()];

            for (int i = 0; i < str.length(); i++) {
                char ch = str.charAt(i);

                for (int j = i + 1; j < str.length(); j++) {
                    char ch1 = str.charAt(j);

                    if (ch != ch1) {
                        counter++;
                    }
                }

                if (counter > temp) {
                    temp = counter;
                    maxchar[currentvalue] = ch;
                    currentvalue++;
                }

            }
            return maxchar;

        }

        public void replaceString() {
            String org = "hello world";
            String[] temp = org.split(" ");
            int len = temp.length;
            String ne = "";
            for (int i = 0; i < len; i++) {
                if (temp[i].matches("car"))
                    temp[i] = "bike";
                ne = ne + temp[i] + " ";

            }
            System.out.println(ne);
        }
