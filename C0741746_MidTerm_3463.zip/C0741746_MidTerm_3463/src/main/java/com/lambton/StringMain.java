package com.lambton;

public class StringMain {

    public static void main(String[] args) {

        LambtonStringTools lst=new LambtonStringTools();
        lst.reverse();

            char[] result = lst.mostFrequent("hello world");
            System.out.println(result);


            lst.initials("welcome to java");

            lst.replaceString();


      /*  public void toString(){

            String.format("the String is ")
        }*/

    }

}






